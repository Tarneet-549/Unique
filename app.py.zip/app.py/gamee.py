from PIL import Image, ImageTk
import tkinter as tk
from tkinter import ttk

# Define your image paths
adaptive_image_path = r"C:\Users\Tarneet singh\OneDrive\Desktop\adaptation.png"
assessment_image_path = r"C:\Users\Tarneet singh\OneDrive\Desktop\analytics.png"
supportive_resources_image_path = r"C:\Users\Tarneet singh\OneDrive\Desktop\resources.png"
gamified_learning_image_path = r"C:\Users\Tarneet singh\OneDrive\Desktop\activity.png"
feedback_image_path = r"C:\Users\Tarneet singh\OneDrive\Pictures\Camera Roll\review.png"
hover_image_path = r"C:\Users\Tarneet singh\OneDrive\Desktop\more-info (1).png"  # The hover image remains the same
large_image_path = r"C:\Users\Tarneet singh\OneDrive\Pictures\rr.jpg"  # Large image on the right side


def open_adaptive_learning_window():
    detail_window = tk.Toplevel(root)
    detail_window.title("Adaptive Learning Paths")
    detail_window.geometry("600x400")
    ttk.Label(detail_window, text="Adaptive Learning Paths", font=("Arial", 20, "bold")).pack(pady=10)
    ttk.Label(detail_window,
              text="Adaptive Learning Paths help personalize your education by tailoring learning experiences "
                   "to your individual needs. Key features include personalized learning goals, customizable resources, "
                   "progress tracking, and adaptive assessments. Explore how these features can support your unique learning journey.",
              font=("Arial", 14), wraplength=550).pack(pady=10, padx=20)
    ttk.Button(detail_window, text="Give Feedback",
               command=lambda: tk.messagebox.showinfo("Feedback", "Feedback Collection Placeholder")).pack(pady=10,
                                                                                                           padx=20)


def open_personalized_assessments_window():
    detail_window = tk.Toplevel(root)
    detail_window.title("Personalized Assessments")
    detail_window.geometry("600x400")
    ttk.Label(detail_window, text="Personalized Assessments", font=("Arial", 20, "bold")).pack(pady=10)
    ttk.Label(detail_window,
              text="Personalized Assessments tailor evaluation methods to suit individual strengths and needs. Features include "
                   "customized test formats, adaptive questioning, and detailed feedback. Understand how these assessments can improve learning outcomes.",
              font=("Arial", 14), wraplength=550).pack(pady=10, padx=20)
    ttk.Button(detail_window, text="Give Feedback",
               command=lambda: tk.messagebox.showinfo("Feedback", "Feedback Collection Placeholder")).pack(pady=10,
                                                                                                           padx=20)


def open_supportive_resources_window():
    detail_window = tk.Toplevel(root)
    detail_window.title("Supportive Resources")
    detail_window.geometry("600x400")
    ttk.Label(detail_window, text="Supportive Resources", font=("Arial", 20, "bold")).pack(pady=10)
    ttk.Label(detail_window,
              text="Supportive Resources provide additional materials to enhance the learning experience. Features include curated reading lists, "
                   "tutorial videos, and interactive exercises. Explore the resources available to support your learning journey.",
              font=("Arial", 14), wraplength=550).pack(pady=10, padx=20)
    ttk.Button(detail_window, text="Give Feedback",
               command=lambda: tk.messagebox.showinfo("Feedback", "Feedback Collection Placeholder")).pack(pady=10,
                                                                                                           padx=20)


def open_gamified_learning_window():
    detail_window = tk.Toplevel(root)
    detail_window.title("Gamified Learning")
    detail_window.geometry("600x400")
    ttk.Label(detail_window, text="Gamified Learning", font=("Arial", 20, "bold")).pack(pady=10)
    ttk.Label(detail_window,
              text="Gamified Learning involves incorporating game elements into educational activities. Features include interactive challenges, "
                   "reward systems, and game-based learning modules. Discover how gamification can make learning more engaging.",
              font=("Arial", 14), wraplength=550).pack(pady=10, padx=20)
    ttk.Button(detail_window, text="Give Feedback",
               command=lambda: tk.messagebox.showinfo("Feedback", "Feedback Collection Placeholder")).pack(pady=10,
                                                                                                           padx=20)


def open_feedback_window():
    detail_window = tk.Toplevel(root)
    detail_window.title("Feedback")
    detail_window.geometry("600x400")
    ttk.Label(detail_window, text="Feedback", font=("Arial", 20, "bold")).pack(pady=10)
    ttk.Label(detail_window,
              text="Feedback allows users to share their experiences and suggestions for improvement. Features include feedback forms, rating systems, "
                   "and comment sections. Learn how to provide feedback and contribute to the platform's development.",
              font=("Arial", 14), wraplength=550).pack(pady=10, padx=20)
    ttk.Button(detail_window, text="Give Feedback",
               command=lambda: tk.messagebox.showinfo("Feedback", "Feedback Collection Placeholder")).pack(pady=10,
                                                                                                           padx=20)


def create_section(parent, title, description, detail_command, static_image_path):
    section_frame = ttk.Frame(parent, padding=10, relief="solid", borderwidth=1)
    section_frame.pack(fill="x", pady=10)

    # Load and display the static image on the left
    static_image = Image.open(static_image_path)
    static_image = static_image.resize((100, 100))  # Resize image as needed
    static_image = ImageTk.PhotoImage(static_image)
    static_image_label = ttk.Label(section_frame, image=static_image)
    static_image_label.image = static_image  # Keep a reference to avoid garbage collection
    static_image_label.pack(side="left", padx=10, pady=10)

    section_text_frame = ttk.Frame(section_frame)
    section_text_frame.pack(side="left", fill="x", expand=True)

    section_label = ttk.Label(section_text_frame, text=title, font=("Arial", 18, "bold"))
    section_label.pack(anchor="w")

    section_desc = ttk.Label(section_text_frame, text=description, font=("Arial", 12))
    section_desc.pack(anchor="w")

    # Load the hover image
    hover_image = Image.open(hover_image_path)
    hover_image = hover_image.resize((100, 100))  # Resize image as needed
    hover_image = ImageTk.PhotoImage(hover_image)

    # Create a Label for the hover image (initially hidden)
    hover_image_label = ttk.Label(section_frame, image=hover_image)
    hover_image_label.image = hover_image  # Keep a reference to avoid garbage collection

    # Make the hover image clickable
    hover_image_label.bind("<Button-1>", lambda e: detail_command())

    def on_enter(event):
        hover_image_label.pack(side="right", padx=10, pady=10)

    def on_leave(event):
        hover_image_label.pack_forget()

    section_frame.bind("<Enter>", on_enter)
    section_frame.bind("<Leave>", on_leave)


# Main application window
root = tk.Tk()
root.title("Personalized Education Platform")
root.geometry("1000x700")  # Increased window size

# Centered Header (Static and Properly Centered)
header_frame = tk.Frame(root, bg="#006666")
header_frame.pack(fill="x", side="top")

header_label = ttk.Label(header_frame, text="Unique Minds Connect", font=("Arial", 28, "bold"), background="#006666",
                         foreground="white", padding=20)
header_label.pack()

# Create a Frame for the scrollable area
main_frame = tk.Frame(root)
main_frame.pack(fill="both", expand=True, padx=10, pady=10)

# Add a Canvas and a Scrollbar
canvas = tk.Canvas(main_frame)
scrollbar = tk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
canvas.configure(yscrollcommand=scrollbar.set)

# Create a Frame inside the Canvas
scrollable_frame = tk.Frame(canvas)
scrollable_frame.bind(
    "<Configure>",
    lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
)

# Add the Frame to the Canvas
canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
scrollbar.pack(side="right", fill="y")
canvas.pack(side="left", fill="both", expand=True)

# Move the canvas into the main frame
canvas.master = main_frame

# Create a Frame below the header for the scrollable content
content_frame = tk.Frame(root)
content_frame.pack(fill="both", expand=True)

# Move the canvas into the content frame
canvas.pack(side="left", fill="both", expand=True)
scrollbar.pack(side="right", fill="y")

# Create a frame for the large image on the right side of the main frame
large_image_frame = tk.Frame(main_frame, padx=10, pady=10)
large_image_frame.pack(side="right", fill="y", padx=10)

# Load and display the large image on the right
large_image = Image.open(large_image_path)
large_image = large_image.resize((500, 500))  # Resize image as needed
large_image = ImageTk.PhotoImage(large_image)
large_image_label = ttk.Label(large_image_frame, image=large_image)
large_image_label.image = large_image  # Keep a reference to avoid garbage collection
large_image_label.pack()

# Sections with different static images
sections = [
    ("Adaptive Learning Paths", "Discover courses that adapt to your learning pace and style.",
     open_adaptive_learning_window, adaptive_image_path),
    ("Personalized Assessments", "Take assessments that are customized to your strengths.",
     open_personalized_assessments_window, assessment_image_path),
    ("Supportive Resources", "Access resources to support your learning journey.", open_supportive_resources_window,
     supportive_resources_image_path),
    ("Gamified Learning", "Engage with interactive, game-based learning experiences.", open_gamified_learning_window,
     gamified_learning_image_path),
    ("Feedback", "Provide and receive feedback to enhance the learning process.", open_feedback_window,
     feedback_image_path),
]

for title, description, detail_command, image_path in sections:
    create_section(scrollable_frame, title, description, detail_command, image_path)

# Footer
footer_label = ttk.Label(root, text="© 2024 Personalized Education Platform. All rights reserved.", font=("Arial", 12),
                         background="#004d4d", foreground="white", padding=10)
footer_label.pack(fill="x", side="bottom")


# Enable smooth scrolling with mouse wheel
def view_scroll(event):
    canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")


canvas.bind_all("<MouseWheel>", view_scroll)

# Run the application
root.mainloop()

