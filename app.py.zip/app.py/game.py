def open_gamified_learning_window():
    # Create a new Toplevel window for the game menu
    game_menu_window = tk.Toplevel(root)
    game_menu_window.title("Gamified Learning")
    game_menu_window.geometry("500x600")
    game_menu_window.configure(bg="skyblue")

    # Initialize the MainMenu class with the new window
    MainMenu(game_menu_window)
import tkinter as tk
import random

class MainMenu:
    def __init__(self, root):
        self.root = root
        self.root.title("Game Menu")
        self.root.geometry("500x600")
        self.root.configure(bg="skyblue")

        tk.Label(self.root, text="Choose a Game", font=("Helvetica", 28, "bold"), bg="skyblue", fg="navy").pack(pady=30)

        buttons = [
            ("Word Puzzle", self.open_word_puzzle),
            ("Jigsaw Puzzle", self.open_jigsaw_puzzle),
            ("Sudoku", self.open_sudoku_game),
            ("Logic Puzzle", self.open_logic_puzzle),
            ("Maze Puzzle", self.open_maze_puzzle),
            ("Crossword Puzzle", self.open_crossword_puzzle),
            ("Match-3 Puzzle", self.open_match3_puzzle)
        ]
        for text, command in buttons:
            tk.Button(self.root, text=text, font=("Helvetica", 18, "bold"), command=command, bg="lightgreen", fg="darkgreen", padx=20, pady=10, relief="raised").pack(pady=10, fill=tk.X, padx=50)

    def open_word_puzzle(self):
        self.open_game(WordPuzzleGame)

    def open_jigsaw_puzzle(self):
        self.open_game(JigsawPuzzleGame)

    def open_sudoku_game(self):
        self.open_game(SudokuGame)

    def open_logic_puzzle(self):
        self.open_game(LogicPuzzleGame)

    def open_maze_puzzle(self):
        self.open_game(MazePuzzleGame)

    def open_crossword_puzzle(self):
        self.open_game(CrosswordPuzzleGame)

    def open_match3_puzzle(self):
        self.open_game(Match3PuzzleGame)

    def open_game(self, game_class):
        self.root.withdraw()  # Hide the main menu
        game_window = tk.Toplevel(self.root)
        game_class(game_window)
        game_window.protocol("WM_DELETE_WINDOW", self.on_close_game_window)

    def on_close_game_window(self):
        self.root.deiconify()  # Show the main menu again
        self.root.quit()  # Quit the application

class WordPuzzleGame:
    def __init__(self, root):
        self.root = root
        self.root.title("Word Puzzle Game")
        self.root.geometry("500x350")
        self.root.configure(bg="lightyellow")

        self.words = ["python", "tkinter", "puzzle", "anagram", "developer"]
        self.current_word = random.choice(self.words)
        self.shuffled_word = "".join(random.sample(self.current_word, len(self.current_word)))

        tk.Label(self.root, text="Unscramble the word", font=("Helvetica", 24, "bold"), bg="lightyellow", fg="darkorange").pack(pady=20)
        tk.Label(self.root, text=self.shuffled_word, font=("Helvetica", 28, "bold"), bg="lightyellow", fg="darkred").pack(pady=10)

        self.entry = tk.Entry(self.root, font=("Helvetica", 18), justify="center", bd=2, relief="solid")
        self.entry.pack(pady=10)

        self.result_label = tk.Label(self.root, text="", font=("Helvetica", 18, "bold"), bg="lightyellow")
        self.result_label.pack(pady=10)

        tk.Button(self.root, text="Submit", font=("Helvetica", 18, "bold"), command=self.check_answer, bg="lightgreen", fg="darkgreen").pack(pady=10)
        tk.Button(self.root, text="Close", font=("Helvetica", 18, "bold"), command=self.root.destroy, bg="lightcoral", fg="darkred").pack(pady=5)

    def check_answer(self):
        answer = self.entry.get().lower()
        if answer == self.current_word:
            self.result_label.config(text="Correct!", fg="green")
        else:
            self.result_label.config(text="Try again!", fg="red")

class JigsawPuzzleGame:
    def __init__(self, root):
        self.root = root
        self.root.title("Jigsaw Puzzle")
        self.root.geometry("400x400")
        self.root.configure(bg="lightblue")

        self.tiles = [i for i in range(1, 9)] + [None]  # 8 tiles + 1 empty space
        random.shuffle(self.tiles)

        self.buttons = []
        for i in range(3):
            row = []
            for j in range(3):
                button = tk.Button(self.root, text=str(self.tiles[i*3+j]) if self.tiles[i*3+j] else "", font=("Helvetica", 20),
                                   width=5, height=2, command=lambda r=i, c=j: self.move_tile(r, c), bg="lightgrey", fg="black", relief="raised")
                button.grid(row=i, column=j, padx=5, pady=5)
                row.append(button)
            self.buttons.append(row)

    def move_tile(self, row, col):
        empty_pos = [(r, c) for r in range(3) for c in range(3) if not self.tiles[r * 3 + c]]
        if empty_pos:
            empty_row, empty_col = empty_pos[0]
            if (abs(empty_row - row) == 1 and empty_col == col) or (abs(empty_col - col) == 1 and empty_row == row):
                self.tiles[empty_row * 3 + empty_col], self.tiles[row * 3 + col] = self.tiles[row * 3 + col], self.tiles[empty_row * 3 + empty_col]
                self.update_buttons()

    def update_buttons(self):
        for i in range(3):
            for j in range(3):
                tile = self.tiles[i * 3 + j]
                self.buttons[i][j].config(text=str(tile) if tile else "")

# Additional game classes (SudokuGame, LogicPuzzleGame, etc.) should be implemented similarly.
